#include <stdio.h>
#include <string.h>
#include "struct.h"
#include "list.c"
#include <stdbool.h>

// Dar de alta a un Alumno
void altaAlumno(ListaDeAlumnos *lista, char *nombreAlumno, int edad) {
    NodoAlumno *node = NewNodoAlumno(NewAlumno(nombreAlumno, edad));

    if (node->datos == NULL){
        printf("Error: no se pudo asignar el estudiante\n");
    }
    if (SizeofLista(lista) == 0){
        lista->head = node;
        lista->tail = node;
    } else {
        lista->tail->prox = node;
        lista->tail = node;
    }
    lista->size++;
}

// Dar de baja a un Alumno
void bajaAlumno(ListaDeAlumnos *lista, char *alumno) {

    if (lista == NULL) {
        printf("Error: La lista está vacía\n");
        return;
    }

    NodoAlumno *actual = lista->head;
    NodoAlumno *anterior = NULL;

    while (actual != NULL && (actual->datos == NULL || actual->datos->nombre != alumno)){
        anterior = actual;
        actual = actual->prox;
    }
    if (lista->head == actual){
        lista->head = actual->prox;

    } else {
            anterior->prox = actual->prox;
    }

    free(actual);
    lista->size--;
}

// Modificar algun alumno en particular ya existente
void modificarAlumno(ListaDeAlumnos *lista, char *nombre, char *nuevoNombre, int nuevaEdad) {

    if (!lista || !nombre || !nuevoNombre) {
        printf("Error: Alguno de los parámetros es inválido\n");
        return;
    }

    NodoAlumno *actual = lista->head;

    while (actual) {
        if (strcmp(actual->datos->nombre, nombre) == 0) {
            strncpy(actual->datos->nombre, nuevoNombre, sizeof(actual->datos->nombre) - 1);
            actual->datos->nombre[sizeof(actual->datos->nombre) - 1] = '\0';
            actual->datos->edad = nuevaEdad;
            return;
        }
        actual = actual->prox;
    }
    printf("Error: no se encontró el alumno con el nombre %s\n", nombre);

}

//Imprime un listado de los alumnos inscriptos
void enlistarAlumnos(ListaDeAlumnos *lista) {

    if (lista == NULL){
        printf("Error: La lista está vacía\n");
    }
    NodoAlumno *actual = lista->head;

    while (actual != NULL){
        printf("Alumno: %s\n", actual->datos->nombre);
        actual = actual->prox;
    }

    printf("\n");

}

// Buscar si el alumno esta dado de Alta
Alumno buscarAlumno(ListaDeAlumnos *lista, char *nombre) {

    while (lista == NULL) {
        printf("Error: La lista está vacía\n");
        break;
    }

    NodoAlumno *actual = lista->head;
    NodoAlumno *alumnoBuscado = NULL;

    while (actual != NULL) {
        if (strcmp(actual->datos->nombre, nombre) == 0) {
            *alumnoBuscado = *actual;
        }
        actual = actual->prox;
    }

    return *alumnoBuscado->datos;
}

// Buscar el alumnos por edad y devolverlos
void buscarAlumnosPorEdad(ListaDeAlumnos *lista, int edad) {

    if (lista != NULL){
        printf("Error: La lista está vacía\n");
    }

    int encontrados = 0;
    int i = 0;
    NodoAlumno *actual = lista->head;

    printf("Alumnos de %d años son:\n", edad);

    while (i < (lista->size)){
        if (actual->datos->edad == edad){
            printf("%s (%d años)\n", actual->datos->nombre, actual->datos->edad);
        }
        actual = actual->prox;
        encontrados++;
        i++;
    }

}



//                 Funciones de materias                 



// Dar de alta una materia
void altaMateria(ListaDeMaterias *lista, char *nombre, int estado, float nota, int regularidad) {

        NodoMateria *node = NewNodoMateria(NewMateria(nombre,&estado,&nota, &regularidad));

        if (node == NULL){
            return;
        }
        if (SizeOfMaterias(lista) == 0){
            lista->head = node;
            lista->tail = node;
        }
        else{
            lista->tail->prox = node;
            lista->tail = node;
        }
        lista->size++;
}

Materia *buscarMateria(ListaDeMaterias *lista, char *nombreMateria) {

    NodoMateria *materia = lista->head;
    while (materia != NULL) {
        if (strcmp(materia->datos->nombre, nombreMateria) == 0) {
            return materia->datos;
        }
        materia = materia->prox;
    }
    return NULL;
}

// Dar de baja una Materia
void bajaMateria(ListaDeMaterias *lista, char *nombreMateria) {
    if (lista == NULL){
        printf("Error: La lista está vacía\n");
        return;
    }

    Materia *materiaBuscada = buscarMateria(lista,nombreMateria);

    NodoMateria *actual = lista->head;
    NodoMateria *anterior = NULL;

    while (actual != NULL && (actual->datos == NULL || actual->datos->nombre != materiaBuscada->nombre)){
        anterior = actual;
        actual = actual->prox;
    }

    if (actual == NULL){
            printf("Error: No se encontrar la materia en la lista \n");
    } else {
        if (lista->head == actual) {
            lista->head = actual->prox;
        } else {
            anterior->prox = actual->prox;
        }
        free(actual);
    }
    lista->size--;
}

// Modificar una materia en cuestion ya existente
void modificarNombreMateria(ListaDeMaterias *lista, char *nombre, char *nuevoNombre) {
    if (lista == NULL || nombre == NULL || nuevoNombre == NULL) {
        printf("Error: Parámetros inválidos\n");
        return;
    }
    Materia *nodo = buscarMateria(lista, nombre);

    if (nodo == NULL) {
        printf("Error: No se encontró la materia con el nombre %s\n", nombre);
        return;
    }

    Materia *materiaAModificar = nodo;
    free(materiaAModificar->nombre);
    materiaAModificar->nombre = (char *) malloc((strlen(nuevoNombre) + 1) * sizeof(char));
    strcpy(materiaAModificar->nombre, nuevoNombre);
}

// Modifica la materia del Alumno para que sea regular en dicha materia, 1 para ser regular, 0 para no serlo.
void modificarRegularidadALumno(ListaDeAlumnos *lista, char *nombreAlumno, char *nombreMateria, int regularidad) {

    if (lista == NULL || nombreAlumno == NULL || nombreMateria == NULL || (regularidad < 0 || regularidad > 1)){
        printf("Error: Alguno de los parametros es incorrecto");
    }

    Alumno alumnoAModificar = buscarAlumno(lista, nombreAlumno);
    NodoMateria *actual = alumnoAModificar.materias->head;

    while (actual->datos->nombre != NULL){
        if (actual->datos->nombre == nombreMateria){
            actual->datos->regularidad = regularidad;
            printf("La regularidad de la materia %s del alumno %s actualizada.\n",
                   nombreMateria, actual->datos->nombre);
            break;
        }
        *actual = *actual->prox;
    }

    printf("No se encontró la materia %s del alumno %s\n", nombreMateria, nombreAlumno);
}

// Agrega una materia a la lista de materias de un alumno
void agregarMateriaAlumno(ListaDeAlumnos *lista, ListaDeMaterias *listaM, char *nombreAlumno, char *nombreMateria){

    if (listaM == NULL || lista == NULL || nombreAlumno == NULL || nombreMateria == NULL){
        printf("Error: Alguno de los parametros es invalido");
        return;
    }

    Alumno actual = buscarAlumno(lista, nombreAlumno);
    Materia *mActual = buscarMateria(listaM, nombreMateria);
    altaMateria(actual.materias, mActual->nombre, mActual->estado,mActual->nota,mActual->regularidad);

}



//----------------------------------

/*
// Lista de los alumnos de una materia especifica
void enlistarAlumnosRegulares(Alumno *listaAlumnos, char *nombreMateria)
{
    Alumno *actual = listaAlumnos;

    while (actual != NULL)
    {
        Materia *materiaActual = actual->materias;

        while (materiaActual != NULL)
        {
            if (strcmp(materiaActual->nombre, nombreMateria) == 0 && materiaActual->regularidad == 1)
            {
                printf("Alumno: %s\n", actual->nombre);
                break;
            }
            materiaActual = materiaActual->proximo;
        }
        actual = actual->proximo;
    }
}

// Edita la materia del alumno con respecto a sus notas.
void editarNotaDelAlumno(Alumno *listaAlumnos, char *nombreAlumno, char *nombreMateria, float nota)
{
    int indiceAlumno = buscarAlumno(listaAlumnos, nombreAlumno);

    if (indiceAlumno == -1)
    {
        printf("No se encontró el alumno %s\n", nombreAlumno);
        return;
    }

    Alumno *alumno = &listaAlumnos[indiceAlumno];
    Materia *cursor = alumno->materias;
    while (cursor != NULL && strcmp(cursor->nombre, nombreMateria) != 0)
    {
        cursor = cursor->proximo;
    }

    if (cursor != NULL)
    {
        cursor->nota = nota;
        if (cursor->regularidad == 1)
        {
            if (nota > 4)
            {
                cursor->estado = 1; // Aprobado
            }
            else
            {
                cursor->estado = 0; // No aprobado
            }
        }
    }
    else
    {
        printf("La materia no existe.\n");
    }
}

// Imprime las materias que tiene un alumno junto a sus detalles
void imprimirMateriasDelAlumno(Alumno *listaAlumnos, char *nombreAlumno)
{
    int indiceAlumno = buscarAlumno(listaAlumnos, nombreAlumno);

    if (indiceAlumno == -1)
    {
        printf("No se encontró el alumno %s\n", nombreAlumno);
        return;
    }

    Alumno *alumno = &listaAlumnos[indiceAlumno];

    printf("Materias del alumno %s:\n", alumno->nombre);

    Materia *cursor = alumno->materias;
    while (cursor != NULL)
    {
        printf("  %s - Nota: %.2f - Regularidad: %s - Estado: %s\n",
               cursor->nombre, cursor->nota,
               cursor->regularidad == 0 ? "Irregular" : "Regular",
               cursor->estado == 0 ? "No aprobado" : "Aprobado");
        cursor = cursor->proximo;
    }
}

void imprimirMaterias(Materia *lista)
{
    while (lista != NULL)
    {
        printf("%s", lista->nombre);
        lista = lista->proximo;
        if (lista != NULL)
        {
            printf(", ");
        }
    }
    printf("\n");
}

//---------------------

Materia *obtenerMateriasNoInscriptas(Alumno *alumno)
{
    Materia *materiasNoInscriptas = NULL;
    Materia *materiaActual = alumno->materias;

    while (materiaActual != NULL)
    {
        Materia *materiaSiguiente = materiaActual->proximo;
        materiaActual->proximo = materiasNoInscriptas;
        materiasNoInscriptas = materiaActual;
        materiaActual = materiaSiguiente;
    }

    return materiasNoInscriptas;
}
// Lista de los alumnos de una materia especifica.
void enlistarAlumnosRegulares(ListaDeAlumnos *lista, char *nombreMateria) {

    if (lista == NULL) {
        printf("Error: La lista se encuentra vacia");
        return;
    }

    NodoAlumno *actual = *lista->head;

    while (actual != NULL) {
        NodoMateria *actualM = actual->datos->materias->head;
        while (actualM != NULL) {
            if (actualM->datos->nombre == nombreMateria && actualM->datos->regularidad == 1) {
                printf("Los alumnos que poseen la materia %s regularizada son:\n", nombreMateria);
                printf("%s", actual->datos->nombre);
            }
            actualM = actualM->prox;
        }
        actual = actual->prox;
    }
}

// Edita la nota de un alumno en una de sus materias.
void editarNotaDelAlumno(ListaDeAlumnos *lista, char *nombreAlumno, char *nombreMateria, float nota) {

    if (lista == NULL) {
        printf("Error: La lista se encuentra vacía");
        return;
    }

    NodoAlumno *actual = *lista->head;

    while (actual != NULL) {
        NodoMateria *actualM = actual->datos->materias->head;
        while (actualM != NULL) {
            if (actual->datos->nombre == nombreAlumno && actualM->datos->nombre == nombreMateria) {
                actualM->datos->nota = nota;
                printf("Se ha actualizado la nota de la materia %s.", nombreMateria);
                if (nota > 3) {
                    actualM->datos->regularidad = 1;
                    actualM->datos->estado = 1; // Aprobado
                } else {
                    actualM->datos->regularidad = 0;
                    actualM->datos->estado = 0;
                }
                return;
            }
            actualM = actualM->prox;
        }
        actual = actual->prox;
    }
}


// Imprime las materias que tiene un alumno junto a sus detalles.
void imprimirMateriasDelAlumno(ListaDeAlumnos *lista,char *nombreAlumno) {

    Alumno actual = buscarAlumno(lista, nombreAlumno);
    NodoMateria *actualM = actual.materias->head;

    while (actualM != NULL){
        printf("  %s - Nota: %.2f - Regularidad: %s - Estado: %s\n",
               actualM->datos->nombre, actualM->datos->nota, actualM->datos->regularidad == 0 ? "Irregular" : "Regular",
               actualM->datos->estado == 0 ? "No aprobado" : "Aprobado");
        actualM = actualM->prox;
    }
}
// Imprime el listado de las materias ingresadas.
void imprimirMaterias(ListaDeMaterias *lista){
    
    if (lista == NULL){
        printf("Error: La lista se encuentra vacía.");
        return;
    }
    
    NodoMateria *actualM = lista->head; 
    
    while (actualM != NULL){
        printf("%s", actualM->datos->nombre);
        actualM = actualM->prox;
        printf("\n");
    }
}
*/