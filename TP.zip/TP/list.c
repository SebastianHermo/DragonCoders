#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include "struct.h"


//Lista de Materias                  


/*
typedef struct structListaDeMaterias {
    NodoMateria *head;
    NodoMateria *tail;
    int size;
} ListaDeMaterias;

ListaDeMaterias *NewListaDeMaterias() {
    ListaDeMaterias *list = (ListaDeMaterias *)malloc(sizeof(ListaDeMaterias));
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
    return list;
}

int SizeOfMaterias(ListaDeMaterias *list) {
    return list->size;
}
*/